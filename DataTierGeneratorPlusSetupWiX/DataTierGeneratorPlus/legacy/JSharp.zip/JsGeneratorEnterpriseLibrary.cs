using System.Collections;
using System.IO;
using System.Text;

namespace DataTierGeneratorPlus
{
	class JsGeneratorEnterpriseLibrary : VsGenerator
	{
		private const string CODE_FOLDER = "\\JSL\\";
		private const string CODE_FILE_EXT = "jsl";
		private const string DBUTIL_FILE_VS_PRE = "Js";

		private string _CodeFolder  = CODE_FOLDER;

		public override string CodeFolder()
		{
			return _CodeFolder;
		}

		public JsGeneratorEnterpriseLibrary() {}
	
		/// <summary>
		/// Creates a J# table structure class for all of the table's fields .
		/// </summary>
		/// <param name="table">Instance of the Table class that represents the table this class will be created for.</param>
		/// <param name="path">Path where the class should be created.</param>
		/// <param name="objSettings">User settings.</param>
		public override void CreateTableStructureClass
			(
			Table table, 
			string path, 
			Settings objSettings
			) 
		{
			Generator.objVsUtility.CreateTableStructureClassCode
				(
				table, 
				path, 
				objSettings
				) ;
		}
		
		public  override void CreateDatabaseUtilityClass(string targetNamespace, string path) 
		{
			//no library needs to be generated
		}

        public override void CreateNullHandlerClass(string targetNamespace, string path)
        {
            using (StreamWriter streamWriter = new StreamWriter(path + "NullHandler." + CODE_FILE_EXT))
            {
                streamWriter.Write(GetNullHandlerClass(targetNamespace));
            }
        }

		/// <summary>
		/// Creates a J# data access base class for all of the table's stored procedures generated automatically.
		/// </summary>
		/// <param name="table">Instance of the Table class that represents the table this class will be created for.</param>
		/// <param name="path">Path where the class should be created.</param>
		/// <param name="objSettings">User settings.</param>
		public override void CreateDataAccessBaseClassSealed
			(
			Table table, 
			string path, 
			Settings objSettings
			)
		{
            string className = Utility.CleanWhitespace(Utility.FormatPascal(table.ProgrammaticAlias + "Controller" + objSettings.ClassSuffix));

			className = Utility.FilterPathCharacters(className);

			// Create the header for the class
			StreamWriter streamWriter = new StreamWriter(path + className + "." + CODE_FILE_EXT);
			streamWriter.WriteLine("package " + objSettings.Namespace + ";");
			streamWriter.WriteLine();
			streamWriter.WriteLine("import System.*;");
			streamWriter.WriteLine("import System.Data.*;");
			streamWriter.WriteLine("import Microsoft.Practices.EnterpriseLibrary.Data.*;");
            streamWriter.WriteLine("import System.ComponentModel.*;//<--use with class and method attributes");

            streamWriter.WriteLine("\t/** @attribute DataObject(true) */ ");
            streamWriter.WriteLine("\tpublic final class " + className + "\n\t{");
			streamWriter.WriteLine("\t\tprivate " + className + "() {}");

			// Append the access methods
            CreateInsertMethod(table, streamWriter, objSettings);
            CreateUpdateMethod(table, streamWriter, objSettings);
            CreateDeleteMethod(table, streamWriter, objSettings);
            CreateDeleteByMethods(table, streamWriter, objSettings);
            CreateSelectMethodReturningDataReader(table, streamWriter, objSettings);
            CreateSelectMethodReturningDataSet(table, streamWriter, objSettings);
            CreateSelectMethodOutputDataReader(table, streamWriter, objSettings);
            CreateSelectMethodOutputDataSet(table, streamWriter, objSettings);
            CreateSelectAllMethodReturningDataReader(table, streamWriter, objSettings);
            CreateSelectAllMethodReturningDataSet(table, streamWriter, objSettings);
            CreateSelectAllMethodOutputDataReader(table, streamWriter, objSettings);
            CreateSelectAllMethodOutputDataSet(table, streamWriter, objSettings);
            CreateSelectByMethodsReturningDataReader(table, streamWriter, objSettings);
            CreateSelectByMethodsReturningDataSet(table, streamWriter, objSettings);
            CreateSelectByMethodsOutputDataReader(table, streamWriter, objSettings);
            CreateSelectByMethodsOutputDataSet(table, streamWriter, objSettings);
            CreateCheckNullMethod(table, streamWriter, objSettings);

			// Close out the class and namespace
			streamWriter.WriteLine("\t}");

			// Flush and close the stream
			streamWriter.Flush();
			streamWriter.Close();
		}

		/// <summary>
		/// Creates a J# data access base class for all of the table's stored procedures generated automatically.
		/// </summary>
		/// <param name="table">Instance of the Table class that represents the table this class will be created for.</param>
		/// <param name="path">Path where the class should be created.</param>
		/// <param name="objSettings">User settings.</param>
		public override void CreateDataAccessBaseClassUnsealed
			(
			Table table, 
			string path, 
			Settings objSettings
			)
		{
            string className = Utility.CleanWhitespace(Utility.FormatPascal(table.ProgrammaticAlias + "Controller" + "Base" + objSettings.ClassSuffix));

			className = Utility.FilterPathCharacters(className);

			// Create the header for the class
			StreamWriter streamWriter = new StreamWriter(path + className + "." + CODE_FILE_EXT);
			streamWriter.WriteLine("package " + objSettings.Namespace + ";");
			streamWriter.WriteLine();
			streamWriter.WriteLine("import System.*;");
			streamWriter.WriteLine("import System.Data.*;");
			streamWriter.WriteLine("import Microsoft.Practices.EnterpriseLibrary.Data.*;");
            streamWriter.WriteLine("import System.ComponentModel.*;//<--use with class and method attributes");

            streamWriter.WriteLine("\t/** @attribute DataObject(true) */ ");
            streamWriter.WriteLine("\tpublic  class " + className + "\n\t{");
			streamWriter.WriteLine("\t\tprotected " + className + "() {}");

			// Append the access methods
            CreateInsertMethod(table, streamWriter, objSettings);
            CreateUpdateMethod(table, streamWriter, objSettings);
            CreateDeleteMethod(table, streamWriter, objSettings);
            CreateDeleteByMethods(table, streamWriter, objSettings);
            CreateSelectMethodReturningDataReader(table, streamWriter, objSettings);
            CreateSelectMethodReturningDataSet(table, streamWriter, objSettings);
            CreateSelectMethodOutputDataReader(table, streamWriter, objSettings);
            CreateSelectMethodOutputDataSet(table, streamWriter, objSettings);
            CreateSelectAllMethodReturningDataReader(table, streamWriter, objSettings);
            CreateSelectAllMethodReturningDataSet(table, streamWriter, objSettings);
            CreateSelectAllMethodOutputDataReader(table, streamWriter, objSettings);
            CreateSelectAllMethodOutputDataSet(table, streamWriter, objSettings);
            CreateSelectByMethodsReturningDataReader(table, streamWriter, objSettings);
            CreateSelectByMethodsReturningDataSet(table, streamWriter, objSettings);
            CreateSelectByMethodsOutputDataReader(table, streamWriter, objSettings);
            CreateSelectByMethodsOutputDataSet(table, streamWriter, objSettings);
            CreateCheckNullMethod(table, streamWriter, objSettings);

			// Close out the class and namespace
			streamWriter.WriteLine("\t}");

			// Flush and close the stream
			streamWriter.Flush();
			streamWriter.Close();
		}

		/// <summary>
		/// Creates an empty J# data access sub class for all of the table's stored procedures created by hand.
		/// </summary>
		/// <param name="table">Instance of the Table class that represents the table this class will be created for.</param>
		/// <param name="path">Path where the class should be created.</param>
		/// <param name="objSettings">User settings.</param>
		public override  void CreateDataAccessSubClass
			(
			Table table, 
			string path, 
			Settings objSettings
			)
		{
            string baseClassName = Utility.CleanWhitespace(Utility.FormatPascal(table.ProgrammaticAlias + "Controller" + "Base" + objSettings.ClassSuffix));
			baseClassName = Utility.FilterPathCharacters(baseClassName);

            string className = Utility.CleanWhitespace(Utility.FormatPascal(table.ProgrammaticAlias + "Controller" + objSettings.ClassSuffix));
			className = Utility.FilterPathCharacters(className);

			// Create the header for the class
			StreamWriter streamWriter = new StreamWriter(path + className + "." + CODE_FILE_EXT);
			streamWriter.WriteLine("package " + objSettings.Namespace + ";");
			streamWriter.WriteLine();
			streamWriter.WriteLine("import System.*;");
			streamWriter.WriteLine("import System.Data.*;");
			streamWriter.WriteLine("import Microsoft.Practices.EnterpriseLibrary.Data.*;");
            streamWriter.WriteLine("import System.ComponentModel.*;//<--use with class and method attributes");

            streamWriter.WriteLine("\t/** @attribute DataObject(true) */ ");
            streamWriter.WriteLine("\tpublic final class " + className + " extends " + baseClassName + "\n\t{");
			streamWriter.WriteLine("\t\tprivate " + className + "() {}");

			// Close out the class and namespace
			streamWriter.WriteLine("\t}");

			// Flush and close the stream
			streamWriter.Flush();
			streamWriter.Close();
		}

		/// <summary>
		/// Creates a string that represents the insert functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override void CreateInsertMethod
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			// Append the method header
			streamWriter.WriteLine();
			streamWriter.WriteLine("\t\t/// <summary>");
			streamWriter.WriteLine("\t\t/// Inserts a record into the " + table.Name + " table.");
			streamWriter.WriteLine("\t\t/// </summary>");
            streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Insert) */ ");

			// Determine the return type of the insert function
			bool returnVoid = true;
			foreach (Column column in table.Columns) {
				if (column.IsIdentity) {
					streamWriter.Write("\t\tpublic static int Insert(");
					returnVoid = false;
					break;
				} else if (column.IsRowGuidCol) {
					streamWriter.Write("\t\tpublic static Guid Insert(");
					returnVoid = false;
					break;
				}
			}

			// If the return type hasn't been set, return void
			if (returnVoid) {
				streamWriter.Write("\t\tpublic static void Insert(");
			}

			// Append the method call parameters
			int remainingColumns = table.Columns.Count;
			foreach (Column column in table.Columns) {
				remainingColumns--;

				if (column.IsIdentity == false && column.IsRowGuidCol == false) {
					if (remainingColumns > 0) {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
					} else {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
					}
				}
			}

			streamWriter.WriteLine(")\n\t\t{");

			bool executeScalar = false;
			// Append the parameter value extraction
			foreach (Column column in table.Columns) {
				if (column.IsIdentity || column.IsRowGuidCol) {
					if (column.IsIdentity) {
						streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
						streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "Insert\");\n");
					} else {
						streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
						streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "Insert\");\n");
					}

					executeScalar = true;
				}
			}

			if (executeScalar == false) {
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "Insert\");\n");
			}

			// Append the parameters
			StringBuilder builder = new StringBuilder();
			foreach (Column column in table.Columns) {
				if (column.IsIdentity == false && column.IsRowGuidCol == false) {
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
				}
			}
			streamWriter.WriteLine(builder.ToString());

			// Append the execution query
			foreach (Column column in table.Columns) {
				if (column.IsIdentity || column.IsRowGuidCol) {
					if (column.IsIdentity) {
						streamWriter.WriteLine("\t\t\t// Execute the query and return the new identity value");
						streamWriter.WriteLine("\t\t\treturn Convert.ToInt32(myDatabase.ExecuteScalar(myCommand));");
					} else {
						streamWriter.WriteLine("\t\t\t// Execute the query and return the new GUID");
						streamWriter.WriteLine("\t\t\tGuid myGuid = new Guid(Convert.ToString(myDatabase.ExecuteScalar(myCommand)));\n");
						streamWriter.WriteLine("\t\t\treturn myGuid;");
					}
				}
			}

			if (executeScalar == false) {
				streamWriter.WriteLine("\t\t\tmyDatabase.ExecuteNonQuery(myCommand);");
			}

			// Append the method footer
			streamWriter.WriteLine("\t\t}");
		}

		/// <summary>
		/// Creates a string that represents the update functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateUpdateMethod
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Updates a record in the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Update) */ ");

				streamWriter.Write("\t\tpublic static void Update(");
				int remainingColumns = table.Columns.Count;
				foreach (Column column in table.Columns) {
					remainingColumns--;

					if (remainingColumns > 0) {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
					} else {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
					}
				}
				streamWriter.WriteLine(")\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "Update\");\n");

				// Append the parameters
				StringBuilder builder = new StringBuilder();
				foreach (Column column in table.Columns) {
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
				}
				streamWriter.WriteLine(builder.ToString());
				streamWriter.WriteLine("\t\t\tmyDatabase.ExecuteNonQuery(myCommand);");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the delete functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateDeleteMethod
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.PrimaryKeys.Count > 0) 
			{
				// Create the delete function based on keys
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Deletes a record from the " + table.Name + " table by a composite primary key.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Delete) */ ");

				streamWriter.Write("\t\tpublic static void Delete(");
				int remainingColumns = table.PrimaryKeys.Count;
				foreach (Column column in table.PrimaryKeys) {
					remainingColumns--;

					if (remainingColumns > 0) {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
					} else {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
					}
				}
				streamWriter.WriteLine(")\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "Delete\");\n");

				// Append the parameters
				StringBuilder builder = new StringBuilder();
				foreach (Column column in table.PrimaryKeys) {
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
				}
				streamWriter.WriteLine(builder.ToString());
				streamWriter.WriteLine("\t\t\tmyDatabase.ExecuteNonQuery(myCommand);");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the "delete by" functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateDeleteByMethods
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			// Create a stored procedure for each foreign key
			foreach (ArrayList compositeKeyList in table.ForeignKeys.Values) 
			{
				// Create the stored procedure name
				StringBuilder stringBuilder = new StringBuilder(255);
				stringBuilder.Append(objSettings.SPPrefix + table.Name + "DeleteBy");
				for (int i = 0; i < compositeKeyList.Count; i++) {
					Column column = (Column) compositeKeyList[i];

					if (i > 0) {
						stringBuilder.Append("_" + Utility.FormatPascal(column.Name));
					} else {
						stringBuilder.Append(Utility.FormatPascal(column.Name));
					}
				}
				string procedureName = stringBuilder.ToString();

				// Create the method name
				stringBuilder = new StringBuilder(255);
				stringBuilder.Append("DeleteBy");
				for (int i = 0; i < compositeKeyList.Count; i++) {
					Column column = (Column) compositeKeyList[i];

					if (i > 0) {
						stringBuilder.Append("_" + Utility.FormatPascal(column.ProgrammaticAlias));
					} else {
						stringBuilder.Append(Utility.FormatPascal(column.ProgrammaticAlias));
					}
				}
				string methodName = stringBuilder.ToString();

				// Create the delete function based on keys
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Deletes a record from the " + table.Name + " table by a foreign key.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Delete) */ ");

				streamWriter.Write("\t\tpublic static void " + methodName + "(");
				int remainingColumns = compositeKeyList.Count;
				foreach (Column column in compositeKeyList) {
					remainingColumns--;

					if (remainingColumns > 0) {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
					} else {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
					}
				}
				streamWriter.WriteLine(")\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + procedureName + "\");\n");

				// Append the parameters
				StringBuilder builder = new StringBuilder();
				foreach (Column column in compositeKeyList) {
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
				}
				streamWriter.WriteLine(builder.ToString());
				streamWriter.WriteLine("\t\t\tmyDatabase.ExecuteNonQuery(myCommand);");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the select by primary key functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectMethodReturningDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects a single record from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

				streamWriter.Write("\t\tpublic static IDataReader SelectDR(");
				int remainingColumns = table.PrimaryKeys.Count;
				foreach (Column column in table.PrimaryKeys) {
					remainingColumns--;

					if (remainingColumns > 0) {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
					} else {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
					}
				}
				streamWriter.WriteLine(")\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "Select\");\n");

				// Append the parameters
				StringBuilder builder = new StringBuilder();
				foreach (Column column in table.PrimaryKeys) {
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
				}
				streamWriter.WriteLine(builder.ToString());
				streamWriter.WriteLine("\t\t\treturn myDatabase.ExecuteReader(myCommand);");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

        /// <summary>
        /// Creates a string that represents the select by primary key functionality of the data access class.
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        /// <param name="objSettings">User settings.</param>
        protected override void CreateSelectMethodReturningDataSet
            (
            Table table,
            StreamWriter streamWriter,
            Settings objSettings
            )
        {
            if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.ForeignKeys.Count)
            {
                // Append the method header
                streamWriter.WriteLine();
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Selects a single record from the " + table.Name + " table.");
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

                streamWriter.Write("\t\tpublic static DataSet SelectDS(");
                int remainingColumns = table.PrimaryKeys.Count;
                foreach (Column column in table.PrimaryKeys)
                {
                    remainingColumns--;

                    if (remainingColumns > 0)
                    {
                        streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
                    }
                    else
                    {
                        streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
                    }
                }
                streamWriter.WriteLine(")\n\t\t{");

                // Append the stored procedure execution
                streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
                streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "Select\");\n");

                // Append the parameters
                StringBuilder builder = new StringBuilder();
                foreach (Column column in table.PrimaryKeys)
                {
                    builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
                }
                streamWriter.WriteLine(builder.ToString());
                streamWriter.WriteLine("\t\t\treturn myDatabase.ExecuteDataSet(myCommand);");

                // Append the method footer
                streamWriter.WriteLine("\t\t}");
            }
        }

		/// <summary>
		/// Creates a string that represents the select by primary key functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectMethodOutputDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects a single record from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

				streamWriter.Write("\t\tpublic static void Select(");
				int remainingColumns = table.PrimaryKeys.Count;
				foreach (Column column in table.PrimaryKeys) 
				{
					remainingColumns--;

					if (remainingColumns > 0) 
					{
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
					} 
					else 
					{
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
					}
				}
				streamWriter.WriteLine(", /** @ref */  IDataReader dr)\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "Select\");\n");

				// Append the parameters
				StringBuilder builder = new StringBuilder();
				foreach (Column column in table.PrimaryKeys) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
				}
				streamWriter.WriteLine(builder.ToString());
				streamWriter.WriteLine("\t\t\tdr = myDatabase.ExecuteReader(myCommand);");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the select by primary key functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectMethodOutputDataSet
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects a single record from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

				streamWriter.Write("\t\tpublic static void Select(");
				int remainingColumns = table.PrimaryKeys.Count;
				foreach (Column column in table.PrimaryKeys) 
				{
					remainingColumns--;

					if (remainingColumns > 0) 
					{
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
					} 
					else 
					{
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
					}
				}
				streamWriter.WriteLine(", /** @ref */  DataSet ds)\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "Select\");\n");

				// Append the parameters
				StringBuilder builder = new StringBuilder();
				foreach (Column column in table.PrimaryKeys) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
				}
				streamWriter.WriteLine(builder.ToString());
				streamWriter.WriteLine("\t\t\tds = myDatabase.ExecuteDataSet(myCommand);");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the select functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectAllMethodReturningDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

				streamWriter.WriteLine("\t\tpublic static IDataReader SelectDRAll()\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "SelectAll\");\n");
				streamWriter.WriteLine("\t\t\treturn myDatabase.ExecuteReader(myCommand);");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

        /// <summary>
        /// Creates a string that represents the select functionality of the data access class.
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        /// <param name="objSettings">User settings.</param>
        protected override void CreateSelectAllMethodReturningDataSet
            (
            Table table,
            StreamWriter streamWriter,
            Settings objSettings
            )
        {
            if (table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count)
            {
                // Append the method header
                streamWriter.WriteLine();
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table.");
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

                streamWriter.WriteLine("\t\tpublic static DataSet SelectDSAll()\n\t\t{");

                // Append the stored procedure execution
                streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
                streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "SelectAll\");\n");
                streamWriter.WriteLine("\t\t\treturn myDatabase.ExecuteDataSet(myCommand);");

                // Append the method footer
                streamWriter.WriteLine("\t\t}");
            }
        }

		/// <summary>
		/// Creates a string that represents the select functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectAllMethodOutputDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

				streamWriter.WriteLine("\t\tpublic static void SelectAll(/** @ref */  IDataReader dr)\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "SelectAll\");\n");
				streamWriter.WriteLine("\t\t\tdr = myDatabase.ExecuteReader(myCommand);");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the select functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectAllMethodOutputDataSet
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

				streamWriter.WriteLine("\t\tpublic static void SelectAll(/** @ref */  DataSet ds)\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + objSettings.SPPrefix + table.Name + "SelectAll\");\n");
				streamWriter.WriteLine("\t\t\tds = myDatabase.ExecuteDataSet(myCommand);");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the "select by" functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectByMethodsReturningDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			// Create a stored procedure for each foreign key
			foreach (ArrayList compositeKeyList in table.ForeignKeys.Values) 
			{
				// Create the stored procedure name
				StringBuilder stringBuilder = new StringBuilder(255);
				stringBuilder.Append(objSettings.SPPrefix + table.Name + "SelectBy");
				for (int i = 0; i < compositeKeyList.Count; i++) {
					Column column = (Column) compositeKeyList[i];

					if (i > 0) {
						stringBuilder.Append("_" + Utility.FormatPascal(column.Name));
					} else {
						stringBuilder.Append(Utility.FormatPascal(column.Name));
					}
				}
				string procedureName = stringBuilder.ToString();

				// Create the method name
				stringBuilder = new StringBuilder(255);
				stringBuilder.Append("SelectDRBy");
				for (int i = 0; i < compositeKeyList.Count; i++) {
					Column column = (Column) compositeKeyList[i];

					if (i > 0) {
						stringBuilder.Append("_" + Utility.FormatPascal(column.ProgrammaticAlias));
					} else {
						stringBuilder.Append(Utility.FormatPascal(column.ProgrammaticAlias));
					}
				}
				string methodName = stringBuilder.ToString();

				// Create the select function based on keys
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table by a foreign key.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

				streamWriter.Write("\t\tpublic static IDataReader " + methodName + "(");
				for (int i = 0; i < compositeKeyList.Count; i++) {
					Column column = (Column) compositeKeyList[i];

					if (i < (compositeKeyList.Count - 1)) {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
					} else {
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
					}
				}
				streamWriter.WriteLine(")\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + procedureName + "\");\n");

				// Append the parameters
				StringBuilder builder = new StringBuilder();
				foreach (Column column in compositeKeyList) {
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
				}
				streamWriter.WriteLine(builder.ToString());
				streamWriter.WriteLine("\t\t\treturn myDatabase.ExecuteReader(myCommand);");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

        /// <summary>
        /// Creates a string that represents the "select by" functionality of the data access class.
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        /// <param name="objSettings">User settings.</param>
        protected override void CreateSelectByMethodsReturningDataSet
            (
            Table table,
            StreamWriter streamWriter,
            Settings objSettings
            )
        {
            // Create a stored procedure for each foreign key
            foreach (ArrayList compositeKeyList in table.ForeignKeys.Values)
            {
                // Create the stored procedure name
                StringBuilder stringBuilder = new StringBuilder(255);
                stringBuilder.Append(objSettings.SPPrefix + table.Name + "SelectBy");
                for (int i = 0; i < compositeKeyList.Count; i++)
                {
                    Column column = (Column)compositeKeyList[i];

                    if (i > 0)
                    {
                        stringBuilder.Append("_" + Utility.FormatPascal(column.Name));
                    }
                    else
                    {
                        stringBuilder.Append(Utility.FormatPascal(column.Name));
                    }
                }
                string procedureName = stringBuilder.ToString();

                // Create the method name
                stringBuilder = new StringBuilder(255);
                stringBuilder.Append("SelectDSBy");
                for (int i = 0; i < compositeKeyList.Count; i++)
                {
                    Column column = (Column)compositeKeyList[i];

                    if (i > 0)
                    {
                        stringBuilder.Append("_" + Utility.FormatPascal(column.ProgrammaticAlias));
                    }
                    else
                    {
                        stringBuilder.Append(Utility.FormatPascal(column.ProgrammaticAlias));
                    }
                }
                string methodName = stringBuilder.ToString();

                // Create the select function based on keys
                // Append the method header
                streamWriter.WriteLine();
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table by a foreign key.");
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

                streamWriter.Write("\t\tpublic static DataSet " + methodName + "(");
                for (int i = 0; i < compositeKeyList.Count; i++)
                {
                    Column column = (Column)compositeKeyList[i];

                    if (i < (compositeKeyList.Count - 1))
                    {
                        streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
                    }
                    else
                    {
                        streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
                    }
                }
                streamWriter.WriteLine(")\n\t\t{");

                // Append the stored procedure execution
                streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
                streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + procedureName + "\");\n");

                // Append the parameters
                StringBuilder builder = new StringBuilder();
                foreach (Column column in compositeKeyList)
                {
                    builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
                }
                streamWriter.WriteLine(builder.ToString());
                streamWriter.WriteLine("\t\t\treturn myDatabase.ExecuteDataSet(myCommand);");

                // Append the method footer
                streamWriter.WriteLine("\t\t}");
            }
        }

		/// <summary>
		/// Creates a string that represents the "select by" functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectByMethodsOutputDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			// Create a stored procedure for each foreign key
			foreach (ArrayList compositeKeyList in table.ForeignKeys.Values) 
			{
				// Create the stored procedure name
				StringBuilder stringBuilder = new StringBuilder(255);
				stringBuilder.Append(objSettings.SPPrefix + table.Name + "SelectBy");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];

					if (i > 0) 
					{
						stringBuilder.Append("_" + Utility.FormatPascal(column.Name));
					} 
					else 
					{
						stringBuilder.Append(Utility.FormatPascal(column.Name));
					}
				}
				string procedureName = stringBuilder.ToString();

				// Create the method name
				stringBuilder = new StringBuilder(255);
				stringBuilder.Append("SelectBy");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];

					if (i > 0) 
					{
						stringBuilder.Append("_" + Utility.FormatPascal(column.ProgrammaticAlias));
					} 
					else 
					{
						stringBuilder.Append(Utility.FormatPascal(column.ProgrammaticAlias));
					}
				}
				string methodName = stringBuilder.ToString();

				// Create the select function based on keys
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table by a foreign key.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

				streamWriter.Write("\t\tpublic static void " + methodName + "(");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];

					if (i < (compositeKeyList.Count - 1)) 
					{
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
					} 
					else 
					{
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
					}
				}
				streamWriter.WriteLine(", /** @ref */  IDataReader dr)\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + procedureName + "\");\n");

				// Append the parameters
				StringBuilder builder = new StringBuilder();
				foreach (Column column in compositeKeyList) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
				}
				streamWriter.WriteLine(builder.ToString());
				streamWriter.WriteLine("\t\t\tdr = myDatabase.ExecuteReader(myCommand);");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the "select by" functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectByMethodsOutputDataSet
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			// Create a stored procedure for each foreign key
			foreach (ArrayList compositeKeyList in table.ForeignKeys.Values) 
			{
				// Create the stored procedure name
				StringBuilder stringBuilder = new StringBuilder(255);
				stringBuilder.Append(objSettings.SPPrefix + table.Name + "SelectBy");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];

					if (i > 0) 
					{
						stringBuilder.Append("_" + Utility.FormatPascal(column.Name));
					} 
					else 
					{
						stringBuilder.Append(Utility.FormatPascal(column.Name));
					}
				}
				string procedureName = stringBuilder.ToString();

				// Create the method name
				stringBuilder = new StringBuilder(255);
				stringBuilder.Append("SelectBy");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];

					if (i > 0) 
					{
						stringBuilder.Append("_" + Utility.FormatPascal(column.ProgrammaticAlias));
					} 
					else 
					{
						stringBuilder.Append(Utility.FormatPascal(column.ProgrammaticAlias));
					}
				}
				string methodName = stringBuilder.ToString();

				// Create the select function based on keys
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table by a foreign key.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/** @attribute DataObjectMethod(DataObjectMethodType.Select) */ ");

				streamWriter.Write("\t\tpublic static void " + methodName + "(");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];

					if (i < (compositeKeyList.Count - 1)) 
					{
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
					} 
					else 
					{
						streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column));
					}
				}
				streamWriter.WriteLine(", /** @ref */  DataSet ds)\n\t\t{");

				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tDatabase myDatabase = DatabaseFactory.CreateDatabase();");
				streamWriter.WriteLine("\t\t\tDBCommandWrapper myCommand = myDatabase.GetStoredProcCommandWrapper(\"" + procedureName + "\");\n");

				// Append the parameters
				StringBuilder builder = new StringBuilder();
				foreach (Column column in compositeKeyList) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + ";\n");
				}
				streamWriter.WriteLine(builder.ToString());
				streamWriter.WriteLine("\t\t\tds = myDatabase.ExecuteDataSet(myCommand);");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Returns the contents of the DatabaseUtility class.
		/// </summary>
		/// <param name="targetNamespace">The namespace to which the code will belong.</param>
		/// <returns>The query that should be used for retrieving column information for the specified table.</returns>
		protected override string GetDatabaseUtilityClass(string targetNamespace) 
		{
			string returnValue = "";
			return returnValue;
		}

        /// <summary>
        /// Returns the contents of the NullHandler class.
        /// </summary>
        /// <param name="targetNamespace">The namespace to which the code will belong.</param>
        /// <returns>The query that should be used for retrieving column information for the specified table.</returns>
        protected override string GetNullHandlerClass(string targetNamespace)
        {
            string returnValue = Utility.GetResource("DataTierGeneratorPlus." + DBUTIL_FILE_VS_PRE + "NullHandler.txt", "#Namespace#", targetNamespace);
            return returnValue;
        }

		/// <summary>
		/// Creates a string for a SqlParameter representing the specified column.
		/// </summary>
		/// <param name="column">Object that stores the information for the column the parameter represents.</param>
		/// <returns>String containing SqlParameter information of the specified column for a method call.</returns>
		protected override string CreateStoredProcedureActualParameterString(Column column)
		{

            return "myCommand.AddInParameter(\"" + Generator.objDbUtility.FormatStoredProcedureParameterName(column.ProgrammaticAlias) + "\", DbType." + Generator.objDbUtility.GetDbTypeFromColumnType(column.Type) + ", CheckNull(" + Utility.FormatCamel(column.ProgrammaticAlias) + "))";

		}

        /// <summary>
        /// Creates a string that represents the "CheckNull" functionality .
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        /// <param name="objSettings">User settings.</param>
        protected override void CreateCheckNullMethod
            (
            Table table,
            StreamWriter streamWriter,
            Settings objSettings
            )
        {
            // Append the method header
            streamWriter.WriteLine();
            streamWriter.WriteLine("\t\t/// <summary>");
            streamWriter.WriteLine("\t\t/// Checks the specified field for an app null value, and returns db null if needed.");
            streamWriter.WriteLine("\t\t/// </summary>");
            streamWriter.WriteLine("\t\tprivate static Object CheckNull(Object Field )");
            streamWriter.WriteLine("\t\t{");
            streamWriter.WriteLine("\t\t\treturn NullHandler.HandleNull(Field, DBNull.Value);");
            streamWriter.WriteLine("\t\t}");
        }

	}
}