using System;
using System.Collections;
using System.IO;
using System.Text;

namespace DataTierGeneratorPlus 
{
	class CpGeneratorBuiltIn  : VsGenerator
	{
		private const string CODE_FOLDER = "\\CPP\\";
		private const string CODE_FILE_EXT = "cpp";
		private const string DBUTIL_FILE_VS_PRE = "Cp";

		private string _CodeFolder  = CODE_FOLDER;

		public override string CodeFolder()
		{
			return _CodeFolder;
		}

		public CpGeneratorBuiltIn() {}
	
		/// <summary>
		/// Creates a C++ table structure class for all of the table's fields .
		/// </summary>
		/// <param name="table">Instance of the Table class that represents the table this class will be created for.</param>
		/// <param name="path">Path where the class should be created.</param>
		/// <param name="objSettings">User settings.</param>
		public override void CreateTableStructureClass
			(
			Table table, 
			string path, 
			Settings objSettings
			) 
		{
			Generator.objVsUtility.CreateTableStructureClassCode
				(
				table, 
				path, 
				objSettings
				) ;
		}
		
		public override void CreateDatabaseUtilityClass(string targetNamespace, string path) 
		{
			using (StreamWriter streamWriter = new StreamWriter(path +  "DatabaseUtility." + CODE_FILE_EXT)) 
			{
				streamWriter.Write(GetDatabaseUtilityClass(targetNamespace));
			}
		}

        public override void CreateNullHandlerClass(string targetNamespace, string path)
        {
            using (StreamWriter streamWriter = new StreamWriter(path + "NullHandler." + CODE_FILE_EXT))
            {
                streamWriter.Write(GetNullHandlerClass(targetNamespace));
            }
        }
		
		/// <summary>
		/// Creates a C++ data access base class for all of the table's stored procedures generated automatically.
		/// </summary>
		/// <param name="table">Instance of the Table class that represents the table this class will be created for.</param>
		/// <param name="path">Path where the class should be created.</param>
		/// <param name="objSettings">User settings.</param>
		public override void CreateDataAccessBaseClassSealed
			(
			Table table, 
			string path, 
			Settings objSettings
			) 
		{
            string className = Utility.CleanWhitespace(Utility.FormatPascal(table.ProgrammaticAlias + "Controller" + objSettings.ClassSuffix));

			className = Utility.FilterPathCharacters(className);
			
			// Create the header for the class
			StreamWriter streamWriter = new StreamWriter(path + className + "." + CODE_FILE_EXT);
			streamWriter.WriteLine("#include \"stdafx.h\"");
			streamWriter.WriteLine();
			streamWriter.WriteLine("using namespace  System;");
			streamWriter.WriteLine("using namespace  System::Collections;");
			streamWriter.WriteLine("using namespace  System::Data;");
			streamWriter.WriteLine("using namespace  System::Data::" + Generator.objDbUtility.DotNetFrameworkClientLib() + ";");
            streamWriter.WriteLine("using namespace System::ComponentModel;//<--use with class and method attributes");
            streamWriter.WriteLine();
			streamWriter.WriteLine("namespace " + objSettings.Namespace + " ");
			streamWriter.WriteLine("{");

            streamWriter.WriteLine("\t [DataObject(true)]");
            streamWriter.WriteLine("\tclass " + className + " {");
			streamWriter.WriteLine("\n\t\t\tprivate:");
			streamWriter.WriteLine("\t\t " + className + "() {}");
			streamWriter.WriteLine("\n\t\t\tpublic:");

			// Create an enum for accessing each of the columns using an integer value, which increases performance
			streamWriter.WriteLine();
			streamWriter.WriteLine("\t\t/// Public constants for column positions on the " + table.Name + " table.");
			for (int i = 0; i < table.Columns.Count; i++) 
			{
				Column column = (Column) table.Columns[i];
				streamWriter.WriteLine("\t\t const static int " + Utility.FormatPascal(column.ProgrammaticAlias) + " = " + i.ToString() + "; //\"const\" reserved for future use and is not implemented.--SJS, 12/28/2005");
			}

			// Append the access methods
            CreateInsertMethod(table, streamWriter, objSettings);
            CreateUpdateMethod(table, streamWriter, objSettings);
            CreateDeleteMethod(table, streamWriter, objSettings);
            CreateDeleteByMethods(table, streamWriter, objSettings);
            CreateSelectMethodReturningDataReader(table, streamWriter, objSettings);
            CreateSelectMethodReturningDataSet(table, streamWriter, objSettings);
            CreateSelectMethodOutputDataReader(table, streamWriter, objSettings);
            CreateSelectMethodOutputDataSet(table, streamWriter, objSettings);
            CreateSelectAllMethodReturningDataReader(table, streamWriter, objSettings);
            CreateSelectAllMethodReturningDataSet(table, streamWriter, objSettings);
            CreateSelectAllMethodOutputDataReader(table, streamWriter, objSettings);
            CreateSelectAllMethodOutputDataSet(table, streamWriter, objSettings);
            CreateSelectByMethodsReturningDataReader(table, streamWriter, objSettings);
            CreateSelectByMethodsReturningDataSet(table, streamWriter, objSettings);
            CreateSelectByMethodsOutputDataReader(table, streamWriter, objSettings);
            CreateSelectByMethodsOutputDataSet(table, streamWriter, objSettings);
            CreateCheckNullMethod(table, streamWriter, objSettings);

			// Close out the class and namespace
			streamWriter.WriteLine("\t};");
			streamWriter.WriteLine("}");

			// Flush and close the stream
			streamWriter.Flush();
			streamWriter.Close();
		}
		
		/// <summary>
		/// Creates a C++ data access base class for all of the table's stored procedures generated automatically.
		/// </summary>
		/// <param name="table">Instance of the Table class that represents the table this class will be created for.</param>
		/// <param name="path">Path where the class should be created.</param>
		/// <param name="objSettings">User settings.</param>
		public override void CreateDataAccessBaseClassUnsealed
			(
			Table table, 
			string path, 
			Settings objSettings
			) 
		{
            string className = Utility.CleanWhitespace(Utility.FormatPascal(table.ProgrammaticAlias + "Controller" + "Base" + objSettings.ClassSuffix));

			className = Utility.FilterPathCharacters(className);
			
			// Create the header for the class
			StreamWriter streamWriter = new StreamWriter(path + className + "." + CODE_FILE_EXT);
			streamWriter.WriteLine("#include \"stdafx.h\"");
			streamWriter.WriteLine();
			streamWriter.WriteLine("using namespace  System;");
			streamWriter.WriteLine("using namespace  System::Collections;");
			streamWriter.WriteLine("using namespace  System::Data;");
			streamWriter.WriteLine("using namespace  System::Data::" + Generator.objDbUtility.DotNetFrameworkClientLib() + ";");
            streamWriter.WriteLine("using namespace System::ComponentModel;//<--use with class and method attributes");
            streamWriter.WriteLine();
			streamWriter.WriteLine("namespace " + objSettings.Namespace + " ");
			streamWriter.WriteLine("{");

            streamWriter.WriteLine("\t [DataObject(true)]");
            streamWriter.WriteLine("\tclass " + className + " {");
			streamWriter.WriteLine("\n\t\t\tprotected:");
			streamWriter.WriteLine("\t\t " + className + "() {}");
			streamWriter.WriteLine("\n\t\t\tpublic:");

			// Create an enum for accessing each of the columns using an integer value, which increases performance
			streamWriter.WriteLine();
			streamWriter.WriteLine("\t\t/// Public constants for column positions on the " + table.Name + " table.");
			for (int i = 0; i < table.Columns.Count; i++) 
			{
				Column column = (Column) table.Columns[i];
				streamWriter.WriteLine("\t\t const static int " + Utility.FormatPascal(column.ProgrammaticAlias) + " = " + i.ToString() + "; //\"const\" reserved for future use and is not implemented.--SJS, 12/28/2005");
			}

			// Append the access methods
            CreateInsertMethod(table, streamWriter, objSettings);
            CreateUpdateMethod(table, streamWriter, objSettings);
            CreateDeleteMethod(table, streamWriter, objSettings);
            CreateDeleteByMethods(table, streamWriter, objSettings);
            CreateSelectMethodReturningDataReader(table, streamWriter, objSettings);
            CreateSelectMethodReturningDataSet(table, streamWriter, objSettings);
            CreateSelectMethodOutputDataReader(table, streamWriter, objSettings);
            CreateSelectMethodOutputDataSet(table, streamWriter, objSettings);
            CreateSelectAllMethodReturningDataReader(table, streamWriter, objSettings);
            CreateSelectAllMethodReturningDataSet(table, streamWriter, objSettings);
            CreateSelectAllMethodOutputDataReader(table, streamWriter, objSettings);
            CreateSelectAllMethodOutputDataSet(table, streamWriter, objSettings);
            CreateSelectByMethodsReturningDataReader(table, streamWriter, objSettings);
            CreateSelectByMethodsReturningDataSet(table, streamWriter, objSettings);
            CreateSelectByMethodsOutputDataReader(table, streamWriter, objSettings);
            CreateSelectByMethodsOutputDataSet(table, streamWriter, objSettings);
            CreateCheckNullMethod(table, streamWriter, objSettings);

			// Close out the class and namespace
			streamWriter.WriteLine("\t};");
			streamWriter.WriteLine("}");

			// Flush and close the stream
			streamWriter.Flush();
			streamWriter.Close();
		}
		
		/// <summary>
		/// Creates an empty C++ data access sub class for all of the table's stored procedures created by hand.
		/// </summary>
		/// <param name="table">Instance of the Table class that represents the table this class will be created for.</param>
		/// <param name="path">Path where the class should be created.</param>
		/// <param name="objSettings">User settings.</param>
		public override void CreateDataAccessSubClass
			(
			Table table, 
			string path, 
			Settings objSettings
			) 
		{
            string baseClassName = Utility.CleanWhitespace(Utility.FormatPascal(table.ProgrammaticAlias + "Controller" + "Base" + objSettings.ClassSuffix));
			baseClassName = Utility.FilterPathCharacters(baseClassName);

            string className = Utility.CleanWhitespace(Utility.FormatPascal(table.ProgrammaticAlias + "Controller" + objSettings.ClassSuffix));
			className = Utility.FilterPathCharacters(className);
			
			// Create the header for the class
			StreamWriter streamWriter = new StreamWriter(path + className + "." + CODE_FILE_EXT);
			streamWriter.WriteLine("#include \"stdafx.h\"");
			streamWriter.WriteLine();
			streamWriter.WriteLine("using namespace  System;");
			streamWriter.WriteLine("using namespace  System::Collections;");
			streamWriter.WriteLine("using namespace  System::Data;");
			streamWriter.WriteLine("using namespace  System::Data::" + Generator.objDbUtility.DotNetFrameworkClientLib() + ";");
            streamWriter.WriteLine("using namespace System::ComponentModel;//<--use with class and method attributes");
            streamWriter.WriteLine();
			streamWriter.WriteLine("namespace " + objSettings.Namespace + " ");
			streamWriter.WriteLine("{");

            streamWriter.WriteLine("\t [DataObject(true)]");
            streamWriter.WriteLine("\tclass " + className + " : public " + baseClassName + " {");
			streamWriter.WriteLine("\n\t\t\tprivate:");
			streamWriter.WriteLine("\t\t " + className + "() {}");
			streamWriter.WriteLine("\n\t\t\tpublic:");

			// Close out the class and namespace
			streamWriter.WriteLine("\t};");
			streamWriter.WriteLine("}");

			// Flush and close the stream
			streamWriter.Flush();
			streamWriter.Close();
		}

		/// <summary>
		/// Creates a string that represents the insert functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override void CreateInsertMethod
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			// Append the method header
			streamWriter.WriteLine();
			streamWriter.WriteLine("\t\t/// <summary>");
			streamWriter.WriteLine("\t\t/// Inserts a record into the " + table.Name + " table.");
			streamWriter.WriteLine("\t\t/// </summary>");
            streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Insert)]");
		
			// Determine the return type of the insert function
			bool returnVoid = true;
			foreach (Column column in table.Columns) 
			{
				if (column.IsIdentity) 
				{
					streamWriter.Write("\t\t static int Insert(");
					returnVoid = false;
					break;
				} 
				else if (column.IsRowGuidCol) 
				{
					streamWriter.Write("\t\t static Guid Insert(");
					returnVoid = false;
					break;
				}
			}
			
			// If the return type hasn't been set, return void
			if (returnVoid) 
			{
				streamWriter.Write("\t\t static void Insert(");
			}
			
			// Append the method call parameters
			foreach (Column column in table.Columns) 
			{
				if (column.IsIdentity == false && column.IsRowGuidCol == false) 
				{
					streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
				}
			}
			
			// Append the connection string parameter
			streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction) {");
			
			// build the parameters collection
			streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
			streamWriter.WriteLine("");
			StringBuilder builder = new StringBuilder();
			foreach (Column column in table.Columns) 
			{
				if (column.IsIdentity == false && column.IsRowGuidCol == false) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
				}
			}
			streamWriter.WriteLine(builder.ToString(0, builder.Length));
			
			bool executeScalar = false;
			// Append the parameter value extraction
			foreach (Column column in table.Columns) 
			{
				if (column.IsIdentity || column.IsRowGuidCol) 
				{
					if (column.IsIdentity) {
						streamWriter.WriteLine("\t\t\t//Execute the query and return the new Guid");
						streamWriter.WriteLine("\t\t\treturn (int) (DatabaseUtility->ExecuteScalar)(connection, transaction, \"" + table.Name + "Insert\", parameters);");
					} 
					else 
					{
						streamWriter.WriteLine("\t\t\t//Execute the query and return the new identity value");
						streamWriter.WriteLine("\t\t\treturn (Guid) (DatabaseUtility->ExecuteScalar)(connection, transaction, \"" + table.Name + "Insert\", parameters);");
					}
					executeScalar = true;
				}
			}
			
			if (executeScalar == false) 
			{
				streamWriter.WriteLine("\t\t\t(DatabaseUtility->ExecuteNonQuery)(connection, transaction, \"" + table.Name + "Insert\", parameters);");
			}
			
			// Append the method footer
			streamWriter.WriteLine("\t\t}");
		}

		/// <summary>
		/// Creates a string that represents the update functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateUpdateMethod
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Updates a record in the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Update)]");
				
				streamWriter.Write("\t\t static void Update(");
				foreach (Column column in table.Columns) 
				{
					streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
				}
				streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction) {");

				// build the parameters collection
				streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
				streamWriter.WriteLine("");
				StringBuilder builder = new StringBuilder();
				foreach (Column column in table.Columns) 
				{
					if (column.IsIdentity == false && column.IsRowGuidCol == false) 
					{
						builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
					}
				}
				streamWriter.WriteLine(builder.ToString(0, builder.Length));
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\t(DatabaseUtility->ExecuteNonQuery)(connection, transaction, \"" + table.Name + "Update\", parameters);");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the delete functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateDeleteMethod
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.PrimaryKeys.Count > 0) 
			{
				// Create the delete function based on keys
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Deletes a record from the " + table.Name + " table by a composite primary key.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Delete)]");
				
				streamWriter.Write("\t\t static void Delete(");
				foreach (Column column in table.PrimaryKeys) {
					streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
				}
				streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction) {");
			
				// build the parameters collection
				streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
				streamWriter.WriteLine("");
				StringBuilder builder = new StringBuilder();
				foreach (Column column in table.PrimaryKeys) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
				}
				streamWriter.WriteLine(builder.ToString(0, builder.Length));
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\t(DatabaseUtility->ExecuteNonQuery)(connection, transaction, \"" + table.Name + "Delete\", parameters);");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the "delete by" functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateDeleteByMethods
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			// Create a stored procedure for each foreign key
			foreach (ArrayList compositeKeyList in table.ForeignKeys.Values) 
			{
				// Create the stored procedure name
				StringBuilder stringBuilder = new StringBuilder(255);
				//stringBuilder.Append(objSettings.SPPrefix + table.Name + "DeleteAllBy");
				stringBuilder.Append(objSettings.SPPrefix + table.Name + "DeleteBy");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];
					
					if (i > 0) 
					{
						stringBuilder.Append("_" + Utility.FormatPascal(column.Name));
					} 
					else 
					{
						stringBuilder.Append(Utility.FormatPascal(column.Name));
					}
				}
				string procedureName = stringBuilder.ToString();

				// Create the method name
				stringBuilder = new StringBuilder(255);
				stringBuilder.Append("DeleteAllBy");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];
					
					if (i > 0) 
					{
						stringBuilder.Append("_" + Utility.FormatPascal(column.ProgrammaticAlias));
					} 
					else 
					{
						stringBuilder.Append(Utility.FormatPascal(column.ProgrammaticAlias));
					}
				}
				string methodName = stringBuilder.ToString();

				// Create the delete function based on keys
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Deletes a record from the " + table.Name + " table by a foreign key.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Delete)]");
				
				streamWriter.Write("\t\t static void " + methodName + "(");
				foreach (Column column in compositeKeyList) 
				{
					streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
				}
				streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction) {");
				
				// build the parameters collection
				streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
				streamWriter.WriteLine("");
				StringBuilder builder = new StringBuilder();
				foreach (Column column in compositeKeyList) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
				}
				streamWriter.WriteLine(builder.ToString(0, builder.Length));
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\t(DatabaseUtility->ExecuteNonQuery)(connection, transaction, \"" + procedureName + "\", parameters);");
				
				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the select by primary key functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectMethodReturningDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects a single record from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");
				
				streamWriter.Write("\t\t static " + Generator.objDbUtility.DotNetFrameworkClientLibDataReader() + " SelectDR(");
				foreach (Column column in table.PrimaryKeys) 
				{
					streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
				}
				streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction) {");
				
				// build the parameters collection
				streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
				streamWriter.WriteLine("");
				StringBuilder builder = new StringBuilder();
				foreach (Column column in table.PrimaryKeys) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
				}
				streamWriter.WriteLine(builder.ToString(0, builder.Length));
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\treturn (DatabaseUtility->ExecuteReader)(connection, transaction, \"" + table.Name + "Select\", parameters);");
				
				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

        /// <summary>
        /// Creates a string that represents the select by primary key functionality of the data access class.
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        /// <param name="objSettings">User settings.</param>
        protected override void CreateSelectMethodReturningDataSet
            (
            Table table,
            StreamWriter streamWriter,
            Settings objSettings
            )
        {
            if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.ForeignKeys.Count)
            {
                // Append the method header
                streamWriter.WriteLine();
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Selects a single record from the " + table.Name + " table.");
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");

                streamWriter.Write("\t\t static DataSet SelectDS(");
                foreach (Column column in table.PrimaryKeys)
                {
                    streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
                }
                streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction) {");

                // build the parameters collection
                streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
                streamWriter.WriteLine("");
                StringBuilder builder = new StringBuilder();
                foreach (Column column in table.PrimaryKeys)
                {
                    builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
                }
                streamWriter.WriteLine(builder.ToString(0, builder.Length));

                // Append the stored procedure execution
                streamWriter.WriteLine("\t\t\treturn (DatabaseUtility->ExecuteDataSet)(connection, transaction, \"" + table.Name + "Select\", parameters);");

                // Append the method footer
                streamWriter.WriteLine("\t\t}");
            }
        }

		/// <summary>
		/// Creates a string that represents the select by primary key functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectMethodOutputDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects a single record from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");
				
				streamWriter.Write("\t\t static void Select(");
				foreach (Column column in table.PrimaryKeys) 
				{
					streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
				}
				streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction, IDataReader *dr) {");
				
				// build the parameters collection
				streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
				streamWriter.WriteLine("");
				StringBuilder builder = new StringBuilder();
				foreach (Column column in table.PrimaryKeys) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
				}
				streamWriter.WriteLine(builder.ToString(0, builder.Length));
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tdr = (DatabaseUtility->ExecuteReader)(connection, transaction, \"" + table.Name + "Select\", parameters);");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");

				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the select by primary key functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectMethodOutputDataSet
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects a single record from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");
				
				streamWriter.Write("\t\t static void Select(");
				foreach (Column column in table.PrimaryKeys) 
				{
					streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
				}
				streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction, DataSet *ds) {");
				
				// build the parameters collection
				streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
				streamWriter.WriteLine("");
				StringBuilder builder = new StringBuilder();
				foreach (Column column in table.PrimaryKeys) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
				}
				streamWriter.WriteLine(builder.ToString(0, builder.Length));
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tds = (DatabaseUtility->ExecuteDataSet)(connection, transaction, \"" + table.Name + "Select\", parameters);");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");
				
				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the select functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectAllMethodReturningDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");

				streamWriter.WriteLine("\t\t static " + Generator.objDbUtility.DotNetFrameworkClientLibDataReader() + " SelectDRAll(" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction) {");
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\treturn (DatabaseUtility->ExecuteReader)(connection, transaction, \"" + table.Name + "SelectAll\");");
				
				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

        /// <summary>
        /// Creates a string that represents the select functionality of the data access class.
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        /// <param name="objSettings">User settings.</param>
        protected override void CreateSelectAllMethodReturningDataSet
            (
            Table table,
            StreamWriter streamWriter,
            Settings objSettings
            )
        {
            if (table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count)
            {
                // Append the method header
                streamWriter.WriteLine();
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table.");
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");

                streamWriter.WriteLine("\t\t static DataSet SelectDSAll(" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction) {");

                // Append the stored procedure execution
                streamWriter.WriteLine("\t\t\treturn (DatabaseUtility->ExecuteDataSet)(connection, transaction, \"" + table.Name + "SelectAll\");");

                // Append the method footer
                streamWriter.WriteLine("\t\t}");
            }
        }

		/// <summary>
		/// Creates a string that represents the select functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectAllMethodOutputDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");

				streamWriter.WriteLine("\t\t static void SelectAll(" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction, IDataReader *dr) {");
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tdr = (DatabaseUtility->ExecuteReader)(connection, transaction, \"" + table.Name + "SelectAll\");");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");
				
				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the select functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectAllMethodOutputDataSet
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			if (table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count) 
			{
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");

				streamWriter.WriteLine("\t\t static void SelectAll(" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction, DataSet *ds) {");
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tds = (DatabaseUtility->ExecuteDataSet)(connection, transaction, \"" + table.Name + "SelectAll\");");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");
				
				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

		/// <summary>
		/// Creates a string that represents the "select by" functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectByMethodsReturningDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			// Create a stored procedure for each foreign key
			foreach (ArrayList compositeKeyList in table.ForeignKeys.Values) 
			{
				// Create the stored procedure name
				StringBuilder stringBuilder = new StringBuilder(255);
				stringBuilder.Append(objSettings.SPPrefix + table.Name + "SelectBy");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];
					
					if (i > 0) {
						stringBuilder.Append("_" + Utility.FormatPascal(column.Name));
					} else {
						stringBuilder.Append(Utility.FormatPascal(column.Name));
					}
				}
				string procedureName = stringBuilder.ToString();

				// Create the method name
				stringBuilder = new StringBuilder(255);
				stringBuilder.Append("SelectDRBy");
				for (int i = 0; i < compositeKeyList.Count; i++) {
					Column column = (Column) compositeKeyList[i];
					
					if (i > 0) {
						stringBuilder.Append("_" + Utility.FormatPascal(column.ProgrammaticAlias));
					} else {
						stringBuilder.Append(Utility.FormatPascal(column.ProgrammaticAlias));
					}
				}
				string methodName = stringBuilder.ToString();

				// Create the select function based on keys
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table by a foreign key.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");
				
				streamWriter.Write("\t\t static " + Generator.objDbUtility.DotNetFrameworkClientLibDataReader() + " " + methodName + "(");
				for (int i = 0; i < compositeKeyList.Count; i++) {
					Column column = (Column) compositeKeyList[i];
					streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
				}
				streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction) {");

				// build the parameters collection
				streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
				streamWriter.WriteLine("");
				StringBuilder builder = new StringBuilder();
				foreach (Column column in compositeKeyList) {
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
				}
				streamWriter.WriteLine(builder.ToString(0, builder.Length));
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\treturn (DatabaseUtility->ExecuteReader)(connection, transaction, \"" + procedureName + "\", parameters);");
				
				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}

        /// <summary>
        /// Creates a string that represents the "select by" functionality of the data access class.
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        /// <param name="objSettings">User settings.</param>
        protected override void CreateSelectByMethodsReturningDataSet
            (
            Table table,
            StreamWriter streamWriter,
            Settings objSettings
            )
        {
            // Create a stored procedure for each foreign key
            foreach (ArrayList compositeKeyList in table.ForeignKeys.Values)
            {
                // Create the stored procedure name
                StringBuilder stringBuilder = new StringBuilder(255);
                stringBuilder.Append(objSettings.SPPrefix + table.Name + "SelectBy");
                for (int i = 0; i < compositeKeyList.Count; i++)
                {
                    Column column = (Column)compositeKeyList[i];

                    if (i > 0)
                    {
                        stringBuilder.Append("_" + Utility.FormatPascal(column.Name));
                    }
                    else
                    {
                        stringBuilder.Append(Utility.FormatPascal(column.Name));
                    }
                }
                string procedureName = stringBuilder.ToString();

                // Create the method name
                stringBuilder = new StringBuilder(255);
                stringBuilder.Append("SelectDSBy");
                for (int i = 0; i < compositeKeyList.Count; i++)
                {
                    Column column = (Column)compositeKeyList[i];

                    if (i > 0)
                    {
                        stringBuilder.Append("_" + Utility.FormatPascal(column.ProgrammaticAlias));
                    }
                    else
                    {
                        stringBuilder.Append(Utility.FormatPascal(column.ProgrammaticAlias));
                    }
                }
                string methodName = stringBuilder.ToString();

                // Create the select function based on keys
                // Append the method header
                streamWriter.WriteLine();
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table by a foreign key.");
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");

                streamWriter.Write("\t\t static DataSet " + methodName + "(");
                for (int i = 0; i < compositeKeyList.Count; i++)
                {
                    Column column = (Column)compositeKeyList[i];
                    streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
                }
                streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction) {");

                // build the parameters collection
                streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
                streamWriter.WriteLine("");
                StringBuilder builder = new StringBuilder();
                foreach (Column column in compositeKeyList)
                {
                    builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
                }
                streamWriter.WriteLine(builder.ToString(0, builder.Length));

                // Append the stored procedure execution
                streamWriter.WriteLine("\t\t\treturn (DatabaseUtility->ExecuteDataSet)(connection, transaction, \"" + procedureName + "\", parameters);");

                // Append the method footer
                streamWriter.WriteLine("\t\t}");
            }
        }

		/// <summary>
		/// Creates a string that represents the "select by" functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectByMethodsOutputDataReader
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			// Create a stored procedure for each foreign key
			foreach (ArrayList compositeKeyList in table.ForeignKeys.Values) 
			{
				// Create the stored procedure name
				StringBuilder stringBuilder = new StringBuilder(255);
				stringBuilder.Append(objSettings.SPPrefix + table.Name + "SelectBy");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];
					
					if (i > 0) 
					{
						stringBuilder.Append("_" + Utility.FormatPascal(column.Name));
					} 
					else 
					{
						stringBuilder.Append(Utility.FormatPascal(column.Name));
					}
				}
				string procedureName = stringBuilder.ToString();

				// Create the method name
				stringBuilder = new StringBuilder(255);
				stringBuilder.Append("SelectAllBy");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];
					
					if (i > 0) 
					{
						stringBuilder.Append("_" + Utility.FormatPascal(column.ProgrammaticAlias));
					} 
					else 
					{
						stringBuilder.Append(Utility.FormatPascal(column.ProgrammaticAlias));
					}
				}
				string methodName = stringBuilder.ToString();

				// Create the select function based on keys
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table by a foreign key.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");
				
				streamWriter.Write("\t\t static void " + methodName + "(");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];
					streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
				}
				streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction, IDataReader *dr) {");

				// build the parameters collection
				streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
				streamWriter.WriteLine("");
				StringBuilder builder = new StringBuilder();
				foreach (Column column in compositeKeyList) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
				}
				streamWriter.WriteLine(builder.ToString(0, builder.Length));
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tdr = (DatabaseUtility->ExecuteReader)(connection, transaction, \"" + procedureName + "\", parameters);");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");
				
				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}
	
		/// <summary>
		/// Creates a string that represents the "select by" functionality of the data access class.
		/// </summary>
		/// <param name="table">The Table instance that this method will be created for.</param>
		/// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
		/// <param name="objSettings">User settings.</param>
		protected override  void CreateSelectByMethodsOutputDataSet
			(
			Table table, 
			StreamWriter streamWriter,
			Settings objSettings
			) 
		{
			// Create a stored procedure for each foreign key
			foreach (ArrayList compositeKeyList in table.ForeignKeys.Values) 
			{
				// Create the stored procedure name
				StringBuilder stringBuilder = new StringBuilder(255);
				stringBuilder.Append(objSettings.SPPrefix + table.Name + "SelectBy");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];
					
					if (i > 0) 
					{
						stringBuilder.Append("_" + Utility.FormatPascal(column.Name));
					} 
					else 
					{
						stringBuilder.Append(Utility.FormatPascal(column.Name));
					}
				}
				string procedureName = stringBuilder.ToString();

				// Create the method name
				stringBuilder = new StringBuilder(255);
				stringBuilder.Append("SelectAllBy");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];
					
					if (i > 0) 
					{
						stringBuilder.Append("_" + Utility.FormatPascal(column.ProgrammaticAlias));
					} 
					else 
					{
						stringBuilder.Append(Utility.FormatPascal(column.ProgrammaticAlias));
					}
				}
				string methodName = stringBuilder.ToString();

				// Create the select function based on keys
				// Append the method header
				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table by a foreign key.");
				streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[DataObjectMethod(DataObjectMethodType::Select)]");
				
				streamWriter.Write("\t\t static void " + methodName + "(");
				for (int i = 0; i < compositeKeyList.Count; i++) 
				{
					Column column = (Column) compositeKeyList[i];
					streamWriter.Write(Generator.objVsUtility.CreateMethodFormalParameter(column) + ", ");
				}
				streamWriter.WriteLine("" + Generator.objDbUtility.DotNetFrameworkClientLibConnection() + " *connection, " + Generator.objDbUtility.DotNetFrameworkClientLibTransaction() + " *transaction, DataSet *ds) {");

				// build the parameters collection
				streamWriter.WriteLine("\t\t\tArrayList *parameters = new ArrayList();");
				streamWriter.WriteLine("");
				StringBuilder builder = new StringBuilder();
				foreach (Column column in compositeKeyList) 
				{
					builder.Append("\t\t\t" + CreateStoredProcedureActualParameterString(column) + "\n");
				}
				streamWriter.WriteLine(builder.ToString(0, builder.Length));
				
				// Append the stored procedure execution
				streamWriter.WriteLine("\t\t\tds = (DatabaseUtility->ExecuteDataSet)(connection, transaction, \"" + procedureName + "\", parameters);");
		
				//Append the Return
				streamWriter.WriteLine("\t\t\treturn;");
				
				// Append the method footer
				streamWriter.WriteLine("\t\t}");
			}
		}
		
		/// <summary>
		/// Returns the contents of the DatabaseUtility class.
		/// </summary>
		/// <param name="targetNamespace">The namespace to which the code will belong.</param>
		/// <returns>The query that should be used for retrieving column information for the specified table.</returns>
		protected override string GetDatabaseUtilityClass(string targetNamespace) 
		{
			string returnValue = Utility.GetResource("DataTierGeneratorPlus." + DBUTIL_FILE_VS_PRE + "DatabaseUtility.txt", "#Namespace#", targetNamespace);
			returnValue = returnValue.Replace("#Command#", Generator.objDbUtility.DotNetFrameworkClientLibCommand());
			returnValue = returnValue.Replace("#DataAdapter#", Generator.objDbUtility.DotNetFrameworkClientLibDataAdapter());
			returnValue = returnValue.Replace("#DataReader#", Generator.objDbUtility.DotNetFrameworkClientLibDataReader());
			returnValue = returnValue.Replace("#Connection#", Generator.objDbUtility.DotNetFrameworkClientLibConnection());
			returnValue = returnValue.Replace("#Transaction#", Generator.objDbUtility.DotNetFrameworkClientLibTransaction());
			returnValue = returnValue.Replace("#Parameter#", Generator.objDbUtility.DotNetFrameworkClientLibParameter());
			return returnValue;
		}

        /// <summary>
        /// Returns the contents of the NullHandler class.
        /// </summary>
        /// <param name="targetNamespace">The namespace to which the code will belong.</param>
        /// <returns>The query that should be used for retrieving column information for the specified table.</returns>
        protected override string GetNullHandlerClass(string targetNamespace)
        {
            string returnValue = Utility.GetResource("DataTierGeneratorPlus." + DBUTIL_FILE_VS_PRE + "NullHandler.txt", "#Namespace#", targetNamespace);
            return returnValue;
        }

		/// <summary>
		/// Creates a string for a SqlParameter representing the specified column.
		/// </summary>
		/// <param name="column">Object that stores the information for the column the parameter represents.</param>
		/// <returns>String containing SqlParameter information of the specified column for a method call.</returns>
		protected override string CreateStoredProcedureActualParameterString(Column column) 
		{
            return "(parameters->Add)(new " + Generator.objDbUtility.DotNetFrameworkClientLibParameter() + "(\"" + Generator.objDbUtility.FormatStoredProcedureParameterName(column.ProgrammaticAlias) + "\", CheckNull(" + Utility.FormatCamel(column.ProgrammaticAlias) + ")));";
		}

        /// <summary>
        /// Creates a string that represents the "CheckNull" functionality .
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        /// <param name="objSettings">User settings.</param>
        protected override void CreateCheckNullMethod
            (
            Table table,
            StreamWriter streamWriter,
            Settings objSettings
            )
        {
            // Append the method header
            streamWriter.WriteLine();
            streamWriter.WriteLine("\t\t/// <summary>");
            streamWriter.WriteLine("\t\t/// Checks the specified field for an app null value, and returns db null if needed.");
            streamWriter.WriteLine("\t\t/// </summary>");
            streamWriter.WriteLine("\t\tprivate:");
            streamWriter.WriteLine("\t\tstatic Object CheckNull(Object Field )");
            streamWriter.WriteLine("\t\t{");
            streamWriter.WriteLine("\t\t\treturn NullHandler->HandleNull(Field, DBNull->Value);");
            streamWriter.WriteLine("\t\t}");
        }

	}
}
