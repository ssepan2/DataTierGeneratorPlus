using System;
using System.Data;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace DataTierGeneratorPlus 
{
	internal sealed class CpUtility : VsUtility 
	{
		
		private const string CODE_FILE_EXT = "cpp";

		public CpUtility() 
		{
		}

		/// <summary>
		/// Creates a string for a method parameter representing the specified column.
		/// </summary>
		/// <param name="column">Object that stores the information for the column the parameter represents.</param>
		/// <returns>String containing parameter information of the specified column for a method call.</returns>
		public override string CreateMethodFormalParameter(Column column)
		{
			return  Generator.objDbUtility.GetDbTypeFromColumnType(column.Type) + " " + Utility.FormatCamel(column.ProgrammaticAlias);
		}
		
		/// <summary>
		/// Creates a C++ table structure class for all of the table's fields .
		/// </summary>
		/// <param name="table">Instance of the Table class that represents the table this class will be created for.</param>
		/// <param name="path">Path where the class should be created.</param>
		/// <param name="objSettings">User settings.</param>
		public override void CreateTableStructureClassCode
			(
			Table table, 
			string path, 
			Settings objSettings
			) 
		{
            string className = Utility.CleanWhitespace(Utility.FormatPascal(table.ProgrammaticAlias + "Info"));

			className = Utility.FilterPathCharacters(className);
			
			// Create the header for the class
			StreamWriter streamWriter = new StreamWriter(path + className + "." + CODE_FILE_EXT);
			streamWriter.WriteLine("#include \"stdafx.h\"");
			streamWriter.WriteLine();
			streamWriter.WriteLine("using namespace System;");
			streamWriter.WriteLine("using namespace System::Collections;");

			streamWriter.WriteLine();
			streamWriter.WriteLine("namespace " + objSettings.Namespace + " {");

            //start class
            streamWriter.WriteLine();
			streamWriter.WriteLine("\t/// <summary>");
			streamWriter.WriteLine("\t/// Class that stores table fields.");
			streamWriter.WriteLine("\t/// </summary>");
			streamWriter.WriteLine("\tpublic class " + className + " {");

            //do default constructor
            streamWriter.WriteLine();
			streamWriter.WriteLine("\t\t/// <summary>");
			streamWriter.WriteLine("\t\t/// Default constructor.  ");
			streamWriter.WriteLine("\t\t/// </summary>");
			streamWriter.WriteLine("\t\t" + className + "() {}");

            //begin constructor with values
            streamWriter.WriteLine();
            streamWriter.WriteLine("\t\t/// <summary>");
            streamWriter.WriteLine("\t\t/// Constructor with values.  ");
            streamWriter.WriteLine("\t\t/// </summary>");
            streamWriter.WriteLine("\t\tpublic " + className + "(");

            // Append the method formal parameters
            StringBuilder builder = new StringBuilder();
            foreach (Column column in table.Columns)
            {
                if (column.IsIdentity == false && column.IsRowGuidCol == false)
                {
                    builder.Append("\t\t\t" + CreateMethodFormalParameter(column) + ",\n");
                }
            }
            streamWriter.WriteLine(builder.ToString(0, builder.Length - 2));

            streamWriter.WriteLine("\t\t)");
            streamWriter.WriteLine("\t\t{");

            // Append the private field assignment statements
            foreach (Column column in table.Columns)
            {
                if (column.IsIdentity == false && column.IsRowGuidCol == false)
                {
                    streamWriter.WriteLine("\t\t\t_" + Utility.FormatPascal(column.ProgrammaticAlias) + " = " + Utility.FormatCamel(column.ProgrammaticAlias) + ";");
                }
            }

            streamWriter.WriteLine("\t\t}");
            //end constructor with values

			// Create a private variable for each of the columns
			streamWriter.WriteLine("\t\tprotected:");
			streamWriter.WriteLine();
			streamWriter.WriteLine("\t\t/// Private variables for columns in the " + table.Name + " table.");
			for (int i = 0; i < table.Columns.Count; i++) 
			{
				Column column = (Column) table.Columns[i];
				streamWriter.WriteLine("\t\t" + Generator.objDbUtility.GetDbTypeFromColumnType(column.Type) + " _" + Utility.FormatPascal(column.ProgrammaticAlias)  + ";");
			}

			// Create a property accessor for each of the columns
			streamWriter.WriteLine("\t\tpublic:");
			streamWriter.WriteLine();
			streamWriter.WriteLine("\t\t/// Public properties for columns in the " + table.Name + " table.");
			for (int i = 0; i < table.Columns.Count; i++) 
			{
				Column column = (Column) table.Columns[i];

				streamWriter.WriteLine();
				streamWriter.WriteLine("\t\t/// <summary>");
				streamWriter.WriteLine("\t\t/// " + Utility.FormatPascal(column.ProgrammaticAlias) + "  ");
				streamWriter.WriteLine("\t\t/// </summary>");
				streamWriter.WriteLine("\t\t" + Generator.objDbUtility.GetDbTypeFromColumnType(column.Type) + " " + Utility.FormatPascal(column.ProgrammaticAlias)  + "{");
				streamWriter.WriteLine("\t\t\tget { return _" + Utility.FormatPascal(column.ProgrammaticAlias)  + "; }");
				streamWriter.WriteLine("\t\t\tset { _" + Utility.FormatPascal(column.ProgrammaticAlias)  + " = value; }");
				streamWriter.WriteLine("\t\t}");
			}

			// Close out the class and namespace
			streamWriter.WriteLine("\t}");
			streamWriter.WriteLine("}");

			// Flush and close the stream
			streamWriter.Flush();
			streamWriter.Close();
		}

	}
}
